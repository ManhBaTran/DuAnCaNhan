/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.poly.form.doihang.service.DoiHangService;

import com.poly.form.doihang.entity.DoiHangResponse.HoaDon;
import java.util.List;

/**
 *
 * @author Admin
 */
public interface IPhieuDoiService {
     
}
