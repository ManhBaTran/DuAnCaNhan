package com.poly.form.khuyenmai.khuyenmai_sanpham.entity;

public class SanPhamForKhuyenMaiResponse {

}
