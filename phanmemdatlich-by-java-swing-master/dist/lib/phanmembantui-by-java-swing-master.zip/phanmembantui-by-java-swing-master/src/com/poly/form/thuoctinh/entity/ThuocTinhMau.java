/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poly.form.thuoctinh.entity;

/**
 *
 * @author longnvph31848
 */
public class ThuocTinhMau {

    private Long IDMau;
    private String maMau;
    private String tenMau;
    private String moTaMau;
    private Integer trangThai;
    private String thoiGianTao;
    private String thoiGianSua;

    public ThuocTinhMau() {
    }

    public ThuocTinhMau(String maMau, String tenMau, String moTaMau, Integer trangThai) {
        this.maMau = maMau;
        this.tenMau = tenMau;
        this.moTaMau = moTaMau;
        this.trangThai = trangThai;
    }

    public ThuocTinhMau(Long IDMau, String maMau, String tenMau, String moTaMau, Integer trangThai) {
        this.IDMau = IDMau;
        this.maMau = maMau;
        this.tenMau = tenMau;
        this.moTaMau = moTaMau;
        this.trangThai = trangThai;
    }

    public Long getIDMau() {
        return IDMau;
    }

    public void setIDMau(Long IDMau) {
        this.IDMau = IDMau;
    }

    public String getMaMau() {
        return maMau;
    }

    public void setMaMau(String maMau) {
        this.maMau = maMau;
    }

    public String getTenMau() {
        return tenMau;
    }

    public void setTenMau(String tenMau) {
        this.tenMau = tenMau;
    }

    public String getMoTaMau() {
        return moTaMau;
    }

    public void setMoTaMau(String moTaMau) {
        this.moTaMau = moTaMau;
    }

    public Integer getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(Integer trangThai) {
        this.trangThai = trangThai;
    }

    public String getThoiGianTao() {
        return thoiGianTao;
    }

    public void setThoiGianTao(String thoiGianTao) {
        this.thoiGianTao = thoiGianTao;
    }

    public String getThoiGianSua() {
        return thoiGianSua;
    }

    public void setThoiGianSua(String thoiGianSua) {
        this.thoiGianSua = thoiGianSua;
    }

    @Override
    public String toString() {
        return "ThuocTinhMau{" + "IDMau=" + IDMau + ", maMau=" + maMau + ", tenMau=" + tenMau + ", moTaMau=" + moTaMau + ", trangThai=" + trangThai + ", thoiGianTao=" + thoiGianTao + ", thoiGianSua=" + thoiGianSua + '}';
    }

}
